# NATH — Devolucions VP, pilot 0.1

Primera entrega: menú Inventari → Devolucions → Shopify / VP, lectura API
acotada a una comanda, importació local i previsualització. No modifica
PinkConnect, no crea transport, TT/DEV ni documents comptables. Sense cron.
El connector original i el codi Shopify es conserven; en instal·lar aquesta
ampliació, el menú Shopify passa a estar sota el nou menú Devolucions.

## Instal·lació en demo

1. Copiar `nath_vp_returns` a custom_addons. Dependències:
   `odoo_pink_connect` i `nath_shopify_returns` 13.0.1.6.7.
2. Reiniciar Odoo, actualitzar la llista d'aplicacions i instal·lar
   «NATH - Devoluciones VP (piloto)». No actualitzar els altres mòduls.
3. Assignar el grup «Devoluciones VP: configuración» a l'usuari de proves.
4. Inventari → Devolucions → VP / PinkConnect → Configuració: crear un
   registre i seleccionar la connexió PinkConnect de la mateixa companyia.
5. Escriure l'ID intern PinkConnect d'una comanda coneguda, no els remarks.

## Primera prova sense accés extern

Al camp Exemple local, posar (substituir 123 per l'ID configurat):

```json
[{"id":"TEST-1","orderId":"123","status":"PENDING"}]
```

Clicar «Importar ejemplo local». Repetir: no ha de duplicar la sol·licitud.
Obrir-la i clicar «Simular / previsualizar». Si no existeix la comanda al
connector, indica revisió; no inventa una associació.

## Primera lectura API

«Leer API (solo lectura)» fa un GET amb orderId i limit=50 a l'API configurada.
No crea ni accepta sol·licituds. La resposta queda a «Respuesta API».
«Importar última respuesta» espera una llista amb id, orderId i status;
si el format real és diferent, s'atura perquè l'adaptem amb una mostra real.
Les dades originals poden contenir informació de clients: compartir-ne només
una mostra anonimitzada, conservant els noms dels camps.

Les consultes no filtren per PENDING expressament: permeten veure també
estats PROCESSING/COMPLETE en repetir la prova. No hi ha paginació automàtica
en aquesta versió; comandes amb 50 resultats poden tenir més dades.

## Pendent per al circuit complet

- Confirmar l'esquema real i implementar lectura paginada i agrupació.
- Validar unitats/SKU/OUT i crear TT/DEV sense repetir devolucions existents.
- Compartir adaptadors Nacex/FedEx amb Shopify sense registres ficticis.
- Crear transport, enviar missatge i adjunt amb recuperació de timeouts.
- Acceptar una línia i rellegir-ne l'estat abans de seguir; provar el
  comportament ES sense Home Pick Up després dels canvis de tipus de VP.
- Recepció, comptabilitat i reemborsament, amb comprovació de duplicats.

No és encara una versió del circuit complet. La instal·lació i execució
dins Odoo 13 s'han de verificar a la demo; les comprovacions locals només
cobreixen sintaxi Python/XML i les proteccions de lectura/importació.
